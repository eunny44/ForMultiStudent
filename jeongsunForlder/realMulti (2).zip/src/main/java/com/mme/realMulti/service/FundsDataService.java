package com.mme.realMulti.service;

import java.util.List;

import com.mme.realMulti.dto.FundsData;

public interface FundsDataService {
	public List<FundsData> getFundsData();
	public List<FundsData> getSearchFundsData(String column, String search_content);
	public void insertFundsData(FundsData fundsData);
	public FundsData latestRow();
	public FundsData ridRow(int rid);
	public void updateFundsData(FundsData fundsData);
}
