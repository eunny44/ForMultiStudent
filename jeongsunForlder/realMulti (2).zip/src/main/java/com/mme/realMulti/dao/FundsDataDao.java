package com.mme.realMulti.dao;

import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.sql.DataSource;

import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.ResultSetExtractor;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.namedparam.BeanPropertySqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.jdbc.core.simple.SimpleJdbcInsert;
import org.springframework.stereotype.Repository;

import com.mme.realMulti.dto.FundsData;
import static com.mme.realMulti.dao.FundsDataDaoSqls.*;
import static com.mme.realMulti.dao.ImgDataDaoSqls.SELECT_IMG_NAME_BY_IMG_ID;
import static com.mme.realMulti.dao.ImgDataDaoSqls.UPDATE_MT_INFO_IMG;

@Repository
public class FundsDataDao {
	private NamedParameterJdbcTemplate jdbc;
	private SimpleJdbcInsert insertAction;
	
	private RowMapper<FundsData> rowMapper = BeanPropertyRowMapper.newInstance(FundsData.class);

	public FundsDataDao(DataSource dataSource) {
		this.jdbc = new NamedParameterJdbcTemplate(dataSource);
		this.insertAction = new SimpleJdbcInsert(dataSource).withTableName("fundsdata");
	}
	
	//학생회비 모두 출력
	public List<FundsData> selectAll(){
		return jdbc.query(SELECT_ALL, Collections.emptyMap(), rowMapper);
	}
	
	//검색한 학생회비 내역 출력 200815
	//https://stackoverflow.com/questions/61207428/like-queries-in-spring-jdbc 참고
	//왠지 모르겟지만 :column이게 안됨... 왜지...
	public List<FundsData> searchFundsData(String column, String search_content){
		System.out.println("Dao : searchFundsData - column:"+column+" search_content"+search_content);
		Map<String,String> params = new HashMap<String,String>();
		params.put("search_content", "%"+search_content+"%");
		if(column.equals("content")) return jdbc.query(SELECT_SEARCH_CONTENT, params, rowMapper);
		else if(column.equals("event")) return jdbc.query(SELECT_SEARCH_EVENT, params, rowMapper);
		else if(column.equals("event_date")) return jdbc.query(SELECT_SEARCH_EVENTDATE, params, rowMapper);
		else return jdbc.query(SELECT_ALL, Collections.emptyMap(), rowMapper);
	}
	
	//학생회비 내역 입력
	public int insert(FundsData fundsData) {
		SqlParameterSource params = new BeanPropertySqlParameterSource(fundsData);
		return insertAction.execute(params);
	}
	
	//학생회비 내역 입력
	public void update(FundsData fundsData) {
		SqlParameterSource params = new BeanPropertySqlParameterSource(fundsData);
		jdbc.update(UPDATE_ROW, params);
	}
	
	//fundsdata에서 가장 마지막에 입력했던 row 반환
	public FundsData latestRow() {
		return jdbc.queryForObject(SELECT_LATEST, Collections.emptyMap(), rowMapper);
	}
	
	//fundsdata에서 특정 rid를 가진 row 반환
	public FundsData ridRow(int rid) {
		Map<String,Integer> params = new HashMap<String,Integer>();
		params.put("rid",rid);
		return jdbc.queryForObject(SELECT_RID, Collections.emptyMap(), rowMapper);
	}
	
	//fundsdata에서 star와 end 기간의 rid와 balance를 반환한다.
	public List<FundsData> selectPeriod(String start, String end){
		Map<String,String> params = new HashMap<String,String>();
		params.put("start", start);
		params.put("end", end);
		return jdbc.query(SELECT_PERIOD, params, rowMapper);
	}
	
	//Insert 할 때, 이로 인해 변경되는 balance들을 모두 수정해줄게요!
	public void updateBalance(int balance, int rid) {
		Map<String, Integer> params = new HashMap<String, Integer>();
		params.put("balance", balance);
		params.put("rid", rid);
		jdbc.update(UPDATE_BALANCE, params);
	}
}
