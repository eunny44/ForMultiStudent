package com.mme.realMulti.service.impl;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.mme.realMulti.dao.FundsDataDao;
import com.mme.realMulti.dto.FundsData;
import com.mme.realMulti.service.FundsDataService;

@Service
public class FundsDataServiceImpl implements FundsDataService{

	@Autowired
	FundsDataDao fundsDataDao;
	
	@Override
	@Transactional
	public List<FundsData> getFundsData() {
		List<FundsData> list = fundsDataDao.selectAll();
		return list;
	}

	@Override
	@Transactional
	public void insertFundsData(FundsData fundsData) {
		fundsDataDao.insert(fundsData);
		List<FundsData> list = fundsDataDao.selectAll();
		updateBalance(fundsData, list);
		/*
		//이제 정보를 업데이트 해줘야함.
		int balance = 0; int flag = 0; String str="";
		//1. 갱신이 필요 없는 balance를 구한다.
		List<FundsData> list = fundsDataDao.selectAll();
		for(FundsData tmp : list){
			if(tmp.getRid()==fundsData.getRid()) break;
			balance = tmp.getBalance();
		}
		//2. 오늘 날짜를 구함
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        Calendar c1 = Calendar.getInstance();
        String strToday = sdf.format(c1.getTime());
        //3. 이 날짜들 간의 balance를 모두 업데이트 해준다.
        list = null;
        str = fundsData.getEvent_date();
        list = fundsDataDao.selectPeriod(str, strToday);
        for(FundsData tmp : list){
			if(tmp.getRid()==fundsData.getRid()) flag=1;
			if(flag==1) {
				balance = balance + tmp.getIncome() - tmp.getOutcome();
				fundsDataDao.updateInsertBalance(balance, tmp.getRid());
			}
		}
		*/
		return;
	}
	
	@Override
	@Transactional
	public void updateFundsData(FundsData fundsData) {
		fundsDataDao.update(fundsData);
		List<FundsData> list = fundsDataDao.selectAll();
		updateBalance(fundsData, list);
		return;
	}

	@Override
	@Transactional
	public FundsData latestRow() {
		return fundsDataDao.latestRow();
	}
	
	@Override
	@Transactional
	public FundsData ridRow(int rid) {
		return fundsDataDao.ridRow(rid);
	}
	
	void updateBalance(FundsData fundsData, List<FundsData> list) {
		//이제 정보를 업데이트 해줘야함.
				int balance = 0; int flag = 0; String str="";
				//1. 갱신이 필요 없는 balance를 구한다. 그게 list로 전달
				for(FundsData tmp : list){
					if(tmp.getRid()==fundsData.getRid()) break;
					balance = tmp.getBalance();
				}
				//2. 오늘 날짜를 구함
				SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
		        Calendar c1 = Calendar.getInstance();
		        String strToday = sdf.format(c1.getTime());
		        //3. 이 날짜들 간의 balance를 모두 업데이트 해준다.
		        list = null;
		        str = fundsData.getEvent_date();
		        list = fundsDataDao.selectPeriod(str, strToday);
		        for(FundsData tmp : list){
					if(tmp.getRid()==fundsData.getRid()) flag=1;
					if(flag==1) {
						balance = balance + tmp.getIncome() - tmp.getOutcome();
						fundsDataDao.updateBalance(balance, tmp.getRid());
					}
				}
		        return;
	}

	@Override
	public List<FundsData> getSearchFundsData(String column, String search_content) {
		System.out.println("Service : getSearchFundsData - column:"+column+" search_content"+search_content);
		return fundsDataDao.searchFundsData(column, search_content);
	}

}
