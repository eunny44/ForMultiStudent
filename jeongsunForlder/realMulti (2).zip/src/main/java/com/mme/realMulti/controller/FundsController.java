package com.mme.realMulti.controller;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
//import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
//import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.mme.realMulti.dto.FundsData;
import com.mme.realMulti.service.ExcelService;
import com.mme.realMulti.service.FundsDataService;

@Controller
//@RequestMapping("/funds")

public class FundsController {
	
	//자동주입 할것들..
	@Autowired
	FundsDataService fundsDataService;
	
	@Autowired
	ExcelService excelService;
	
	@ModelAttribute("cp")
	public String getContextPath(HttpServletRequest request) {
		return request.getContextPath();
	}
	
	@PostMapping(path="/excelDown.do")
	public void excelDown(HttpServletResponse response) throws Exception {
        excelService.getExcelDown(response);
	}

	@PostMapping(path="/fundsDataInsert")
	public String fundsDataInsert(Model model, HttpServletRequest request) {
		FundsData fundsData = new FundsData();
		FundsData tmp_fundsData = new FundsData();
		tmp_fundsData = fundsDataService.latestRow();
		int income; int outcome; String str="";
		
		
		if(request.getParameter("income")=="") income = 0;
		else {
			str="";
			str = request.getParameter("income");
			str = str.replaceAll(",", "");
			income = Integer.parseInt(str);
		}
		
		if(request.getParameter("outcome")=="") outcome=0;
		else {
			str="";
			str = request.getParameter("outcome");
			str = str.replaceAll(",", "");
			outcome = Integer.parseInt(str);
		}
		
		fundsData.setRid(tmp_fundsData.getRid()+1);
		fundsData.setPrid(tmp_fundsData.getRid()+1);
		fundsData.setEvent_date(request.getParameter("cur_date"));
		fundsData.setEvent(request.getParameter("event"));
		fundsData.setContent(request.getParameter("content"));
		fundsData.setIncome(income);
		fundsData.setOutcome(outcome);
		fundsData.setBalance(0);

		fundsDataService.insertFundsData(fundsData);
		
		return "redirect:/fundsAdmin";
	}
	
	@PostMapping(path="/fundsDataModify")
	public String fundsDataModify(Model model, HttpServletRequest request) {
		FundsData fundsData = new FundsData();
		//FundsData tmp_fundsData = new FundsData();
		//tmp_fundsData = fundsDataService.ridRow(Integer.parseInt(request.getParameter("rid")));
		int income; int outcome; String str="";
		
		
		if(request.getParameter("income")=="") income = 0;
		else {
			str="";
			str = request.getParameter("income");
			str = str.replaceAll(",", "");
			income = Integer.parseInt(str);
		}
		
		if(request.getParameter("outcome")=="") outcome=0;
		else {
			str="";
			str = request.getParameter("outcome");
			str = str.replaceAll(",", "");
			outcome = Integer.parseInt(str);
		}
		
		fundsData.setRid(Integer.parseInt(request.getParameter("rid")));
		fundsData.setPrid(Integer.parseInt(request.getParameter("prid")));
		fundsData.setEvent_date(request.getParameter("cur_date"));
		fundsData.setEvent(request.getParameter("event"));
		fundsData.setContent(request.getParameter("content"));
		fundsData.setIncome(income);
		fundsData.setOutcome(outcome);
		fundsData.setBalance(0);
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        Calendar c1 = Calendar.getInstance();
        String strToday = sdf.format(c1.getTime());
        fundsData.setUpdate_date(strToday);

		fundsDataService.updateFundsData(fundsData);
		
		return "redirect:/fundsAdmin";
	}
	
	@PostMapping(path="/fundsDataSearch")
	public String fundsDataSearch(Model model, HttpServletRequest request, RedirectAttributes redirectAttr) {
		List<FundsData> list = null;
		if(request.getParameter("column").equals("all")) return "redirect:/fundsUser";
		else {
			redirectAttr.addFlashAttribute("column", request.getParameter("column"));
			redirectAttr.addFlashAttribute("search_content", request.getParameter("search_content"));
			return "redirect:/searchFundsUser";
		}
	}
	
	/*
	@RequestMapping("/fundsAdmin")
	@GetMapping(path="/funds/fundsAdmin")
	public String fundsAdmin(Model model, HttpServletRequest request) {
		return "funds/fundsAdmin";
	}

	*/
	
}
