package com.mme.realMulti.service;

import java.util.List;
import com.mme.realMulti.dto.Student;

public interface StudentService {
	public List<Student> getStudents();
}