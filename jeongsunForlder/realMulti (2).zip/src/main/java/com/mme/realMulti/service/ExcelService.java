package com.mme.realMulti.service;

import javax.servlet.http.HttpServletResponse;

public interface ExcelService {
	public void getExcelDown(HttpServletResponse response);
}
