package com.mme.realMulti.dao;

public class FundsDataDaoSqls {
	
	//학생회비 모든 내역을 출력합니다.
	public static final String SELECT_ALL = "SELECT rid,prid,event,content,income,outcome,balance,DATE_FORMAT(event_date,'%Y-%m-%d') event_date ,DATE_FORMAT(update_date,'%Y-%m-%d') update_date FROM fundsdata ORDER BY event_date, event";
	
	//학생회비에서 검색한 내역을 출력합니다.
	public static final String SELECT_SEARCH = "SELECT rid,prid,event,content,income,outcome,balance,DATE_FORMAT(event_date,'%Y-%m-%d') event_date ,DATE_FORMAT(update_date,'%Y-%m-%d') update_date FROM fundsdata WHERE :column like :search_content ORDER BY event_date, event";
	
	//학생회비 데이터에서 가장 최신에 입력한 데이터를 가져옵니다.
	public static final String SELECT_LATEST = "SELECT * FROM fundsdata ORDER BY rid desc limit 1";
	
	//학생회비 데이터에서 특정 rid값을 가진 데이터를 가져옵니다.
	public static final String SELECT_RID = "SELECT * FROM fundsdata WHERE rid=:rid";

	//학생회비의 특정 기간 내역을 반환합니다.
	public static final String SELECT_PERIOD = "Select * From (Select * From fundsdata Order By event_date, event) A Where A.event_date BETWEEN :start AND :end Order By event_date, event";

	//학생회비 balance를 업데이트 합니다.
	public static final String UPDATE_BALANCE = "Update fundsdata SET balance=:balance WHERE rid=:rid";
	
	//학생회비 데이터에서 특정 rid 값을 가진 데이터를 업데이트합니다.
	public static final String UPDATE_ROW = "Update fundsdata SET prid=:prid, event_date=:event_date, event=:event, content=:content, income=:income, outcome=:outcome, balance=:balance, update_date=:update_date WHERE rid=:rid";
}
