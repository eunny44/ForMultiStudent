package kr.or.multi.multiCommunity.service;

import java.util.List;
import kr.or.multi.multiCommunity.dto.Student;

public interface StudentService {
	public List<Student> getStudents();
}